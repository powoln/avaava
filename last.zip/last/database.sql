-- 1. 데이터베이스 생성
CREATE DATABASE IF NOT EXISTS shopping_mall;
USE shopping_mall;

-- 2. 도서(book) 테이블 생성
CREATE TABLE IF NOT EXISTS book (
    id VARCHAR(50) PRIMARY KEY,     -- 도서 ID (ISBN+날짜 형식)
    name VARCHAR(100) NOT NULL,     -- 도서명
    price INT NOT NULL,             -- 가격
    author VARCHAR(50),             -- 저자
    description TEXT,               -- 설명
    category VARCHAR(50),           -- 분야
    release_date VARCHAR(50)        -- 출판일
);