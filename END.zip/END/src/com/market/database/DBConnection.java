package com.market.database;

import java.sql.*;
import com.market.cart.Cart;
import com.market.cart.CartItem;
import com.market.member.UserInIt;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/shopping_mall?serverTimezone=UTC";
    private static final String USER = "root"; 
    private static final String PASSWORD = "root";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("드라이버를 찾을 수 없습니다.");
        }
    }

    /**
     * [추가] member 테이블에 사용자 정보를 저장하거나 업데이트합니다.
     * 외래 키 제약 조건 에러를 방지하기 위해 주문 전 반드시 실행되어야 합니다.
     */
    public static void saveMember(String name, String phone, String address) {
        String sql = "INSERT INTO member (name, phone, address) VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE name = ?, address = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, address);
            pstmt.setString(4, name);    // 업데이트용
            pstmt.setString(5, address); // 업데이트용
            
            pstmt.executeUpdate();
            System.out.println("회원 정보(member)가 DB에 반영되었습니다.");
        } catch (SQLException e) {
            System.out.println("회원 정보 저장 오류: " + e.getMessage());
        }
    }

    public static void insertBook(String[] bookData) {
        String sql = "INSERT INTO book (id, name, price, author, description, category, release_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, bookData[0]);
            pstmt.setString(2, bookData[1]);
            pstmt.setInt(3, Integer.parseInt(bookData[2]));
            pstmt.setString(4, bookData[3]);
            pstmt.setString(5, bookData[4]);
            pstmt.setString(6, bookData[5]);
            pstmt.setString(7, bookData[6]);
            
            pstmt.executeUpdate();
            System.out.println("DB 저장 성공");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void saveUser(String name, String email) {
        String sql = "SELECT m.address, o.total_price, oi.book_id, oi.quantity " +
                     "FROM member m " +
                     "LEFT JOIN orders o ON m.phone = o.user_email " +
                     "LEFT JOIN order_items oi ON o.order_id = oi.order_id " +
                     "WHERE m.name = ? AND m.phone = ? " +
                     "ORDER BY o.order_date DESC LIMIT 1"; 
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String dbAddress = rs.getString("address");
                    if (UserInIt.getmUser() != null) {
                        UserInIt.getmUser().setAddress(dbAddress);
                    }
                    System.out.println("\n========== 고객 정보 및 최근 주문 내역 ==========");
                    System.out.println("고객명 : " + name);
                    System.out.println("주문한 도서 : " + rs.getString("book_id"));
                    System.out.println("주문한 도서의 수량 : " + rs.getInt("quantity"));
                    System.out.println("총 금액 : " + rs.getInt("total_price") + "원");
                    System.out.println("================================================\n");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void insertOrder(String email, Cart cart, int finalPrice) {
        String orderSql = "INSERT INTO orders (user_email, total_price) VALUES (?, ?)";
        String itemSql = "INSERT INTO order_items (order_id, book_id, quantity) VALUES (?, ?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false); 

            PreparedStatement pstmtOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            pstmtOrder.setString(1, email);
            pstmtOrder.setInt(2, finalPrice);
            pstmtOrder.executeUpdate();

            ResultSet rs = pstmtOrder.getGeneratedKeys();
            int orderId = rs.next() ? rs.getInt(1) : 0;

            PreparedStatement pstmtItem = conn.prepareStatement(itemSql);
            for (CartItem item : cart.mCartItem) {
                pstmtItem.setInt(1, orderId);
                pstmtItem.setString(2, item.getBookID());
                pstmtItem.setInt(3, item.getQuantity());
                pstmtItem.addBatch();
            }
            pstmtItem.executeBatch();
            
            conn.commit(); 
            System.out.println("주문 정보가 DB에 안전하게 기록되었습니다.");
            
        } catch (SQLException e) {
            System.out.println("[오류] 주문 처리 중 에러 발생, 작업이 취소되었습니다.");
            e.printStackTrace();
        }
    }
}