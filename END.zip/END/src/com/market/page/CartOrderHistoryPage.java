package com.market.page;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;          // Connection, ResultSet, PreparedStatement 등
import java.util.Vector;    // 테이블 데이터를 담기 위한 벡터
import com.market.database.DBConnection; // DB 연결 클래스
import com.market.member.UserInIt;       // 사용자 정보 클래스

public class CartOrderHistoryPage extends JPanel {

    public CartOrderHistoryPage(JPanel panel) {
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);
        setLayout(new BorderLayout());

        // 메인 패널 크기 설정
        Rectangle rect = panel.getBounds();
        setPreferredSize(rect.getSize());

        // 1. 제목 영역
        JLabel titleLabel = new JLabel("내 주문 내역 확인", JLabel.CENTER);
        titleLabel.setFont(new Font("함초롬돋움", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // 2. 테이블 헤더(컬럼) 설정
        Vector<String> columnNames = new Vector<>();
        columnNames.add("주문번호");
        columnNames.add("주문자 이메일");
        columnNames.add("총 결제금액");
        columnNames.add("주문 일시");

        // 3. 테이블 데이터 로드 (DB 연동)
        Vector<Vector<Object>> data = new Vector<>();
        
        // SQL: 현재 로그인한 사용자의 이메일과 일치하는 주문 정보를 최신순으로 가져옴
        String sql = "SELECT * FROM orders WHERE user_email = ? ORDER BY order_id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // 현재 로그인한 사용자의 Phone(이메일) 설정
            pstmt.setString(1, UserInIt.getmUser().getPhone());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("order_id"));        // 주문 번호
                row.add(rs.getString("user_email"));   // 사용자 이메일
                row.add(rs.getInt("total_price") + "원"); // 총 금액
                row.add(rs.getTimestamp("order_date")); // 주문 시간
                data.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "데이터베이스 연결 오류: " + e.getMessage());
        }

        // 4. 테이블 생성 및 패널 추가
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 테이블 내용 수정 금지
            }
        };

        JTable table = new JTable(model);
        table.setFont(ft);
        table.setRowHeight(30); // 행 높이 조절
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }
}